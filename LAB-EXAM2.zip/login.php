<?php

	$name = $pass = $check="";
	
	$nameErr = $passErr = $checkErr=""; //setting empty vars to hold err msgs
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	$name = $_POST['name'];
	$pass =  $_POST['pass'];
	
	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="my_db";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	 
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}else{
		$sql = "insert into login values ('".$name."','".$pass."')";
	}
	
	
	mysqli_query($conn,$sql);
	mysqli_close($conn);	

	if(empty ($_POST["name"])){
	$nameErr = "Field required";
	}	else
	{
	$name = test_input($_POST["name"]);
									// check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
    }

	}
	
	if(empty ($_POST["pass"])){
	$passErr = "Field required";
	}
	else
	{
	$pass = test_input($_POST["pass"]);
	if (preg_match('/[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/', $pass)) //pass must contain numeric and letters both
	{
    $passErr = " secure enough";
	}
	else
	{
	$passErr = " not secure enough";	
	}
	}
	
	if(empty ($_POST["check"])){
	$checkErr = "Field required";
	}
	else
	{
	$check = test_input($_POST["check"]);
	}
	
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="" method="POST">
        <table border="0" cellspacing="0" cellpadding="0">
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" name="name" placeholder="name"/></td>
				<span class="error">* <?php echo $nameErr;?></span>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" name="pass" placeholder="*********"/></td>
				<span class="error">* <?php echo $passErr;?></span>	
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>