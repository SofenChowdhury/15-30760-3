<?php 
	require_once "include/headerN.php";
	require_once "include/accounts.php";
?>
<fieldset>
    <legend><b>PROFILE</b></legend>
	<form>
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td>Bob</td>
				<td rowspan="7" align="center">
					<img width="128" src="image/user.png"/>
                    <br/>
                    <a href="picture.php">Change</a>
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>bob@aiub.edu</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td>Male</td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td>19/09/1998</td>
			</tr>
		</table>	
        <hr/>
        <a href="edite.php">Edit Profile</a>	
	</form>
</fieldset>
<?php 
	require_once "include/footerN.php";
?>