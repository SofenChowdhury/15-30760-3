<?php 
	require_once "include/header.php";
?>

<fieldset>
    <legend><b>FORGOT PASSWORD</b></legend>
    <form>
		Enter Email:
        <input type="password" />
        <hr />
        <input type="submit" value="Submit" />
    </form>
</fieldset>

<?php 
	require_once "include/footer.php";
?>