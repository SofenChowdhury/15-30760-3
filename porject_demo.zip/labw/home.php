<?php 
	require_once "include/header.php";
?>
<h2> Welcome to Online Exam</h2>
<p align="left"><b>Terms and Condition  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;time:2 hr</b></p>
	<li align="left">Qus all the ans.</li>
	<li align="left">All the ans in the Qus.</li>
	<li align="left">Submit before in 2 hr otherwise fail.</li>
<?php 
	require_once "include/footer.php";
?>