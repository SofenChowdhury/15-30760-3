<?php 
	session_start();
	if(isset($_SESSION["email"]) ){
		require_once "include/headerAdmin.php";
		require_once "include/accountsAdmin.php";
?>
<h1>Welcome Feculty Home Page!<br/>Email:&nbsp; <?=$_SESSION["email"]?></h1>
<?php 
	require_once "include/footerN.php";
?>
<?php
	}else{
		echo "Please login first";
	}
?>