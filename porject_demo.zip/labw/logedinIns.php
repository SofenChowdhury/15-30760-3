<?php 
	session_start();
	if(isset($_SESSION["email"]) ){
		require_once "include/headerIns.php";
		require_once "include/accountsIns.php";
?>
<h1>Welcome Instructor Home Page!<br/>Email:&nbsp; <?=$_SESSION["email"]?></h1>
<?php 
	require_once "include/footerN.php";
?>
<?php
	}else{
		echo "Please login first";
	}
?>