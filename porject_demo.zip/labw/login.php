<?php
	session_start();
	require "include/db.php";

	if($_SERVER['REQUEST_METHOD']=='POST'){
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		$sql = "SELECT * FROM ltable WHERE email='$email' and password = '$password'";
		$result = mysqli_query($con,$sql);
		$count = mysqli_num_rows($result);
		$row = mysqli_fetch_assoc($result);
		If($count==1)
		{
			if($row['type'] == "feculty"){
				$_SESSION["email"]= $_POST['email'];
				header("Location: logedinAdmin.php");
			}elseif($row['type'] == "instructor"){
				$_SESSION["email"]= $_POST['email'];
				header("Location: logedinIns.php");
			}else{
				$_SESSION["email"]= $_POST['email'];
				header("Location: logedin.php");
			}
		}else{
			header('location: login.php');
		}
	}
?>

<?php 
	require_once "include/header.php";
?>
<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method="POST" onsubmit="return getEmail()">
        <table>
            <tr>
                <td>User Email</td>
				<td>:</td>
                <td><input type="email" name="email" id='email'  /></td>
				<td id='emailError'></td>
			</tr>
            <tr>
                <td>User Password</td>
				<td>:</td>
                <td><input type="password" name="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="submit" value="Submit">        
		<a href="forget.php">Forgot Password?</a>
    </form>
</fieldset>
<?php 
	require_once "include/footer.php";
?>
<script type="text/javascript" src='login.js'></script>