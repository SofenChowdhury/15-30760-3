
function getName(){
	var a = document.getElementById('name').value;
	//alert(a);
	document.getElementById('nameError').innerHTML= a;
}