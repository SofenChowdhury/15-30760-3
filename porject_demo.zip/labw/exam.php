<?php 
	require_once "include/headerN.php";
	require_once "include/accounts.php";
?>
<fieldset>
    <legend><b>Exam Paper</b></legend>
    <form enctype="multipart/form-data" method="POST" action="#">
        Choose File:<input type="file" name="file">
		<input type="submit" name="submit" value="upload">
    </form>
</fieldset>
<?php
	require_once "include/footerN.php";
?>