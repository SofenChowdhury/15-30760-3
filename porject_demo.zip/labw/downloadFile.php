<?php 

?>

<?php 
	require_once "include/headerN.php";
	require_once "include/accounts.php";
?>
<fieldset>
    <legend><b>File Upload</b></legend>
    <form enctype="multipart/form-data" method="POST" action="#">
        Choose File:<input type="file" name="file">
    </form>
</fieldset>
<?php
	require_once "include/footerN.php";
?>