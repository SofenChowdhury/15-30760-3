<?php 
	require_once "include/headerIns.php";
	require_once "include/accountsIns.php";
?>
<fieldset>
    <legend><b>Exam Paper</b></legend>
    <form enctype="multipart/form-data" method="POST" action="#">
        Download File:<input type="file" name="file">
    </form>
</fieldset>
<?php
	require_once "include/footerN.php";
?>