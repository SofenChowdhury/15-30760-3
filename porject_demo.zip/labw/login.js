
function getEmail(){
	
	var a = document.getElementById('email').value;
		document.getElementById('emailError').innerHTML= a;
		debugger;
		return false;
	
	document.getElementById('emailError').innerHTML= a;
}