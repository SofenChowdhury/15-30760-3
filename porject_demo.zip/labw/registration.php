<?php 
	$output = null;$type="admin";
	$name=$email=$user=$password=$confirm=$gender=$dob="";
	require_once "include/db.php";
	//$mysqli = NEW MySQLi('localhost','root','','mydb');
	if(isset($_POST['submit'])){
		$name       = $_POST['name'];
		$email      = $_POST['email'];
		$id          = $_POST['id'];
		$password   = $_POST['password'];
		$confirm    = $_POST['confirm'];
		$sql = "insert into mytable values ('".$name."','".$email."','".$id."','".$password."','".$type."')";
		$result = mysqli_query($con, $sql);
		//$row = mysqli_fetch_assoc($result);
		$output = "ball";
		
		/* $sql = "select * from usertable where user='".$user."'";
		$result = mysqli_query($con, $sql);
		//$count = mysqli_num_rows($result);
	
		if(empty($name) OR empty($email) OR empty($password) OR empty($confirm) OR empty($gender) OR empty($dob)){
			$output = "Please Fill in all fields.";
		}elseif($count != 0){
			$output = "That name is already taken.";
		}elseif($confirm != $password){
			$output = "Your password don't match.";
		}elseif(strlen($password) < 6){
			$output = "Your password must be at least 5 characters.";
		}else{
			$password = md5($password);
			$sql1 = "insert into usertable values ('".$name."','".$email."','".$user."','".$password."','".$gender."','".$dob."')";
			mysqli_query($con,$sql1);
			//$insert = mysqli_connect"INSERT INTO table(name,email,user,password,gender,dob) VALUES('$name','$email','$user','$password','$gender','$dob')");
			if($sql1 != TRUE){
				$output = "There was a problem <br />";
				$output .= $con->error;
			}else{
				$output = "You have been registered!";
			}
		 }*/
	}
	mysqli_close($con);
?>
<?php
	echo $output;
?>
<?php 
	require_once "include/header.php";
?>
<fieldset>
<legend><b>REGISTRATION</b></legend>
	<form method="POST" action="#">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Full Name</td>
				<td>:</td>
				<td><input name="name" type="text"></td>
				<td></td>
			</tr>
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="email">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>ID</td>
				<td>:</td>
				<td><input name="id" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirm" type="password"></td>
				<td></td>
			</tr>	
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
		</table>
		<hr/>
		<input type="submit" name="submit" value="Submit">
		<!--<input type="reset" name="reset" value="reset">!-->
	</form>
</fieldset>
<?php 
	require_once "include/footer.php";
?>