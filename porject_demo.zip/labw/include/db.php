<?php
	
	$servername = "localhost";
	$username 	= "root";
	$userpassword	= "";
	$dbname		= "sofen";
	
	$con = mysqli_connect($servername, $username, $userpassword, $dbname);
	//$mysqli = NEW MySQLi('localhost','root','','mydb');
?>