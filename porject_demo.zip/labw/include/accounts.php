 </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="190" valign="top">
            <b>&nbsp;Account</b><hr />
            <ul>
                <li><a href="#">Dashboard</a></li>
				<li><a href="exam.php">Exan Paper</a></li>
				<li><a href="downloadFile.php">Download File</a></li>
                <li><a href="profile.php">View Profile</a></li>
                <li><a href="picture.php">Change Profile Picture</a></li>
                <li><a href="change.php">Change Password</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </td>
        <td valign="top">