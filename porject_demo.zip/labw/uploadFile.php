
<?php 

require_once("db.php");
//mysql_select_db("file");
if(isset($_REQUEST["submit"])){
	$file=$_FILES["file"]["name"];
	$tmp_name=$_FILES["file"]["tmp_name"];
	$path="upload/".$file;
	$file1=explode(".",$file);
	$ext=$file1[1];
	$allowed=array("jpg","png","gif","pdf","wmv","pdf","zip");
	if(in_array($ext,$allowed))
	{
		move_uploaded_file($tmp_name,$path);
		mysqli_query("insert into upload(file) value('$file')");
	}
}

?>

<?php 
	require_once "include/headerAdmin.php";
	require_once "include/accountsAdmin.php";
?>
<fieldset>
    <legend><b>File Upload</b></legend>
    <form enctype="multipart/form-data" method="POST" action="#">
        Choose File:<input type="file" name="file">
		<input type="submit" name="submit" value="upload">
    </form>
</fieldset>
<?php
	require_once "include/footerN.php";
?>