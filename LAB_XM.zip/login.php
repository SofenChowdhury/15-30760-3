<?php
	if(isset($_POST['submit']))
	{
		$id   = trim($_POST['id']);
		$pass = trim($_POST['pass']);
		
		/*$con = mysqli_connect('localhost','root','','webtec');
		$sql = "insert into user values(".$id.",'".$name."','".$pass."','".$repass."','".$type."')";
		
		mysqli_query($con,$sql);
		mysqli_close($con);*/
		
		$data = "ID  :".$id."\r\n";
		$data.= "PASS:".$pass."\r\n";
		
		$f = fopen("login.txt","w");
		fwrite($f,$data);
		fclose($f);
		/*$f     = fopen("login.txt","r");
		$file    = fgets($f,$data);
		$myarray = explode(':',$file);
		fclose($f);*/
	}
?>
<center>
<form>
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<br/><a href="admin_home.html">Go Admin</a><br/>
					<br/><a href="user_home.html">Go User</a><br/>
					<br/><a href="home.html">Go Home</a><br/>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>

