<?php
	if(isset($_POST['submit']))
	{
		$pass       = trim($_POST['pass']);
		$newpass 	= trim($_POST['newpass']);
		$repass     = trim($_POST['repass']);
		
		/*$con = mysqli_connect('localhost','root','','webtec');
		$sql = "insert into user values(".$id.",'".$name."','".$pass."','".$repass."','".$type."')";
		
		mysqli_query($con,$sql);
		mysqli_close($con);*/
		
		$data = "PASS   :".$pass."\r\n";
		$data .= "NEWPASS:".$newpass."\r\n";
		$data .= "REPASS :".$repass."\r\n";
		
		$f=fopen("change_password.txt","w");
		fwrite($f,$data);
		fclose($f);
		
		/*$f=fopen("ff.txt","r");
		$file=fgets($f,$data);
		$myarray = explode(':',$file);
		fclose($f);*/
		
	}

?>
<center>
<form>
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<br/><br/><a href="user_home.html">GO User</a><br/>
					<br/><a href="home.html">GO Home</a><br/>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>