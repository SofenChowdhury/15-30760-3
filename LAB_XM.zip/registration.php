<?php
	if(isset($_POST['submit']))
	{
		$id   	= trim($_POST['id']);
		$name 	= trim($_POST['name']);
		$pass 	= trim($_POST['pass']);
		$repass = trim($_POST['repass']);
		$type 	= trim($_POST['type']);
		
		/*$con = mysqli_connect('localhost','root','','webtec');
		$sql = "insert into user values(".$id.",'".$name."','".$pass."','".$repass."','".$type."')";
		
		mysqli_query($con,$sql);
		mysqli_close($con);*/
		
		$data  = "ID  :".$id."\r\n";
		$data .= "NAME:".$name."\r\n";
		$data .= "PASS:".$pass."\r\n";
		$data .= "TYPE:".$type."\r\n";
		
		$f=fopen("registration.txt","w");
		fwrite($f,$data);
		fclose($f);
		
		/*$f=fopen("ff.txt","r");
		$file=fgets($f,$data);
		$myarray = explode(':',$file);
		fclose($f);*/
		
	}

?>
<center>
<form>
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
				<br/><a href="admin_home.html">GO Admin</a><br/>
					<br/><a href="user_home.html">GO User</a><br/>
					<br/><a href="home.html">GO Home</a><br/>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>