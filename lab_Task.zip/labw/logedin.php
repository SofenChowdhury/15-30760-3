<?php 
	require_once "include/headerN.php";
?>
<?php 
	require_once "include/accounts.php";
?>
<h1>Welcome Bob</h1>
<?php 
	require_once "include/footerN.php";
?>