<?php 
	require_once "include/header.php";
?>
<h2> Welcome to xCompany </h2>

<?php 
	require_once "include/footer.php";
?>